﻿/************************************Copyright*****************************************
*        ProjectName:AKNet
*        Web:https://github.com/825126369/AKNet
*        Description:C#游戏网络库
*        Author:许珂
*        StartTime:2024/11/01 00:00:00
*        ModifyTime:2025/11/30 19:43:20
*        Copyright:MIT软件许可证
************************************Copyright*****************************************/
using System;
using AKNet.Common;
namespace AKNet.MSQuic.Client
{
    public interface QuicClientPeerBase
    {
        void ConnectServer(string Ip, int nPort);
        bool DisConnectServer();
        void ReConnectServer();
        void Update(double elapsed);
        void Reset();
        void Release();

        void addNetListenFunc(ushort nPackageId, Action<QuicClientPeerBase, NetPackage> fun);
        void removeNetListenFunc(ushort nPackageId, Action<QuicClientPeerBase, NetPackage> fun);
        void addNetListenFunc(Action<QuicClientPeerBase, NetPackage> func);
        void removeNetListenFunc(Action<QuicClientPeerBase, NetPackage> func);

        void addListenClientPeerStateFunc(Action<QuicClientPeerBase, SOCKET_PEER_STATE> mFunc);
        void removeListenClientPeerStateFunc(Action<QuicClientPeerBase, SOCKET_PEER_STATE> mFunc);
        void addListenClientPeerStateFunc(Action<QuicClientPeerBase> mFunc);
        void removeListenClientPeerStateFunc(Action<QuicClientPeerBase> mFunc);
    }
}
